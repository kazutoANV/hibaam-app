HIBAAM.UZ - Android ilova (WebView)

A) Android Studio (kompyuter):
   1. File > Open > shu papkani tanlang
   2. Gradle sync tugashini kuting
   3. Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk

B) Telefondan / kompyutersiz (GitHub):
   1. github.com'da yangi repo oching, shu papkadagi hamma fayllarni yuklang
      (".github" papkasi ham bo'lishi shart)
   2. Repo > Actions > "Build APK" ishga tushadi (3-5 daqiqa)
   3. Tugagach "hibaam-apk" artifactini yuklab oling, ichidagi app-debug.apk ni o'rnating

HTML o'zgarsa: app/src/main/assets/index.html ni almashtiring.

GOOGLE KIRISH SOZLAMASI (Google Cloud Console > APIs & Services > Credentials):
  1. "Web application" tipidagi OAuth Client ID (saytda Admin panelga kiritiladigan shu ID).
  2. YANGI "Android" tipidagi OAuth Client ID yarating:
       Package name: uz.hibaam.app
       SHA-1: 59:5B:B3:AB:1A:EE:B4:06:FC:D6:40:2C:06:00:92:E5:59:8F:55:74
  3. OAuth consent screen "Testing" holatida bo'lsa, o'zingizning Gmail'ingizni Test users ga qo'shing.
  Admin panel > Sayt sozlamalari > "Google Client ID" ga WEB client ID ni kiriting.
